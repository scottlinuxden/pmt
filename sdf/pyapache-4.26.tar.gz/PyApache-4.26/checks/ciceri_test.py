#!/usr/local/bin/python
#
# Copyright (c) 1996 by Lele Gaifax.  All Rights Reserved
#
# This file is part of PyApache
#
# ciceri_test.py,v
# 1.1
# 2001/06/07 10:22:28
#
# Created Wed Nov  6 10:45:28 1996.
#

print "Content-type: text/html"
print
print "<HTML>"
print "<TITLE>Test form output: Hello zanzi</TITLE>"

print "<BODY>"
print "Here I am"
print "</BODY>"
print "</HTML>"
