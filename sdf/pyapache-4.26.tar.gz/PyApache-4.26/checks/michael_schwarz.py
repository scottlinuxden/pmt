import time

print "Content-type: text/html"
print
today = time.localtime(0)
today_string = time.strftime("%Y%m%d", today)
print today_string

