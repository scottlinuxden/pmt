#!/usr/bin/python
print "Content-type: text/plain"
print "Location: http://www.rufus.org\n\n"
