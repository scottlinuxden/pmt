#!/usr/local/bin/python
#
# Copyright (c) 1997 by Lele Gaifax.  All Rights Reserved
#
# This file is part of PyApache.
#
# softspace.py,v
# 1.1
# 2001/06/07 10:22:11
#
# Created Fri Mar  7 19:05:54 1997.
#

print "Content-type: text/html"
print

print "a", "b", "c"
