print 'PMOD'

print dir()

try:
	print 'pmod persistdict=', __persistdict__
except:
	print 'pmod persistdict unknown'


