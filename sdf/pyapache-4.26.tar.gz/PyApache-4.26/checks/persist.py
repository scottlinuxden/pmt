#!/usr/bin/python
#
# This file is part of PyApache.
#
# persist.py,v
# 1.1
# 2001/06/07 10:22:11
#
# Created long time ago.
#

# Test out the persistent dictionary feature: here, each time
# we are called, we try to increment an `int' slot in that
# dictionary, or we set to 1 if the key is not there.

print "Content-type: text/plain\n"

import sys
print "PATH: ", sys.path

globals = __persistdict__
try:
	__persistdict__['int'] = __persistdict__['int']+1
except:
	__persistdict__['int'] = 1


import testpmod

print dir()
try:
	print 'persistdict=', __persistdict__
except:
	print 'persistdict unknown'

__persistdict__['key']='value'



