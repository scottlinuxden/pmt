#!/usr/local/bin/python1.5
#
# Copyright (c) 1998 by Lele Gaifax.  All Rights Reserved
#
# This file is part of PyApache.
#
# RCSfile:  multipart.py,v
# Revision: 1.1
# Date:     2001/06/07 10:22:11
#
# Created Wed May 27 18:27:46 1998.
#

#! /usr/home/drew/product/bin/python
# this cgi gives an unending list of ">  < 0" lines in the browser (when
# using the plugin -- works as expected when doing normal cgi)
import sys
import os

print "Content-Type: text/plain\n\n"

m=int(os.environ["CONTENT_LENGTH"])
print "CONTENT_LENGTH", m

total=0
while total < m:
    t=sys.stdin.readline()
    print ">",t,"<", len(t)
    total=total+len(t)

print "length=%d" % (total)

#o=sys.stdin.readlines() # <-- this gives AttributeError: readlines
