import DateTime
print "Content-type: text/html"
print
today = DateTime.now()
today_string = today.strftime("%Y%m%d")
print today_string

