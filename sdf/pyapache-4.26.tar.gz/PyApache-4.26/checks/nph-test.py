#!/usr/local/bin/python
#
# Copyright (c) 1996 by Lele Gaifax.  All Rights Reserved
#
# This file is part of PyApache.
#
# nph-test.py,v
# 1.1
# 2001/06/07 10:22:11
#
# Created Thu May 16 11:48:21 1996.
#

import sys, string, os

def getenv (name):
    if os.environ.has_key (name):
	return os.environ[name]
    else:
	return ""
    # end if
# end def

print "HTTP/1.0 200 OK"
print "Content-type: text/plain"
print "Server: ", getenv ('SERVER_SOFTWARE')
print 

print "CGI/1.0 test script report:"
print 

print "argc is %d. argv is '%s'." % (len (sys.argv), string.join (sys.argv))
print

print "SERVER_SOFTWARE = ", getenv ('SERVER_SOFTWARE')
print "SERVER_NAME = ", getenv ('SERVER_NAME')
print "GATEWAY_INTERFACE = ", getenv ('GATEWAY_INTERFACE')
print "SERVER_PROTOCOL = ", getenv ('SERVER_PROTOCOL')
print "SERVER_PORT = ", getenv ('SERVER_PORT')
print "REQUEST_METHOD = ", getenv ('REQUEST_METHOD')
print "HTTP_ACCEPT = ", getenv ('HTTP_ACCEPT')
print "PATH_INFO = ", getenv ('PATH_INFO')
print "PATH_TRANSLATED = ", getenv ('PATH_TRANSLATED')
print "SCRIPT_NAME = ", getenv ('SCRIPT_NAME')
print "QUERY_STRING = ", getenv ('QUERY_STRING')
print "REMOTE_HOST = ", getenv ('REMOTE_HOST')
print "REMOTE_ADDR = ", getenv ('REMOTE_ADDR')
print "REMOTE_USER = ", getenv ('REMOTE_USER')
print "CONTENT_TYPE = ", getenv ('CONTENT_TYPE')
print "CONTENT_LENGTH = ", getenv ('CONTENT_LENGTH')

sys.stderr.write ('This is the end\n')
