#!/usr/local/bin/python
#
# Copyright (c) 1997 by Lele Gaifax.  All Rights Reserved
#
# This file is part of PyApache.
#
# py-test-cgi.py,v
# 1.1
# 2001/06/07 10:22:11
#
# Created Mon Jun 30 23:28:30 1997.
#

import sys, os

print "Content-type: text/plain"
print
print

print "CGI/1.0 test script report:"
print

print 'argc is %d. argv is "%s".' % (len (sys.argv), `sys.argv`)
print

def ev(v):
    try:
	s = os.environ[v]
    except KeyError:
	s = ""
    # end try
    return s
# end def

print 'PID = ', os.getpid()
print 'SERVER_SOFTWARE =', ev('SERVER_SOFTWARE')
print 'SERVER_NAME =', ev('SERVER_NAME')
print 'GATEWAY_INTERFACE =', ev('GATEWAY_INTERFACE')
print 'SERVER_PROTOCOL =', ev('SERVER_PROTOCOL')
print 'SERVER_PORT =', ev('SERVER_PORT')
print 'REQUEST_METHOD =', ev('REQUEST_METHOD')
print 'HTTP_ACCEPT = "' + ev('HTTP_ACCEPT') + '"'
print 'PATH_INFO = "' + ev('PATH_INFO') + '"'
print 'PATH_TRANSLATED = "' + ev('PATH_TRANSLATED') + '"'
print 'SCRIPT_NAME = "' + ev('SCRIPT_NAME') + '"'
print 'QUERY_STRING = "' + ev('QUERY_STRING') + '"'
print 'REMOTE_HOST = ', ev('REMOTE_HOST')
print 'REMOTE_ADDR = ', ev('REMOTE_ADDR')
print 'REMOTE_USER = ', ev('REMOTE_USER')
print 'AUTH_TYPE = ', ev('AUTH_TYPE')
print 'CONTENT_TYPE = ', ev('CONTENT_TYPE')
print 'CONTENT_LENGTH = ', ev('CONTENT_LENGTH')

try:
    __persistdict__['azy'] = __persistdict__['azy']+1
except:
    __persistdict__['azy'] = 1
# end try

print "AZY = ",  __persistdict__['azy']
