
import sys

class testclass:
    def __init__(self, name):
	self.name = name
	self.myerr = open ('/dev/console','w')

    def __repr__(self):
	return 'testclass("%s")' % self.name

    def __del__(self):
	self.myerr.write ( "Deleting ``%s''\n" % self.name)
	self.myerr.close()

zero = testclass('zero')
zero.myerr.write ('TESTMOD imported\n')
zero.myerr.flush()
