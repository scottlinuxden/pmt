#!/usr/local/bin/python
#
# Copyright (c) 1996 by Lele Gaifax.  All Rights Reserved
#
# This file is part of PyApache.
#
# location.py,v
# 1.1
# 2001/06/07 10:22:11
#
# Created Thu Jun 27 19:05:13 1996.
#

print "Content-type: text/plain"
print "Location: /~lele/pychecks/location2.py"
print # end-of-headers
