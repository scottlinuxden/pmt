#!/usr/bin/python

print "Content-type: text/plain"
print "Location: /~lele/pychecks/persist.py\n"

