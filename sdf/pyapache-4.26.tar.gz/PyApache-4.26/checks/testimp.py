#!/usr/local/bin/python
#
# Copyright (c) 1996 by Lele Gaifax.  All Rights Reserved
#
# This file is part of PyApache.
#
# testimp.py,v
# 1.1
# 2001/06/07 10:22:11
#
# Created Tue Jun 25 14:57:47 1996.
#

print "Content-type: text/html"
print # end-of-headers

print "<H1>Testing IMPORT functionalities</H1>"

import testimp_mod

testimp_mod.say_hello()

print "<H2>Python 1.5 Test Suite</H2>"

import sys


import regrtest
sys.argv[1:] = ["-vv"]
regrtest.main()
