#!/usr/local/bin/python
#
# Copyright (c) 1996 by Lele Gaifax.  All Rights Reserved
#
# This file is part of PyApache.
#
# testimp_mod.py,v
# 1.1
# 2001/06/07 10:22:11
#
# Created Tue Jun 25 15:00:22 1996.
#

print "<H2>This comes from the module testimp_mod</H2>"

counter = 1

def say_hello():
    global counter
    
    print "<H3>Hello from the module testimp_mod<H3>"
    print "This method got %d hits" % counter
    counter = counter + 1
# end def


