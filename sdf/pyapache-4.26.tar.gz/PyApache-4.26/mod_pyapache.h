/* This file is part of PyApache.
 * Copyright (C) 1996,97,98,99 by Lele Gaifax.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * as published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

/*
 * RCSfile:  mod_pyapache.h,v
 * Revision: 4.10
 * Date:     2001/06/03 19:41:50
 *
 * Created Thu Aug 14 09:11:48 1997.
 */

#ifndef _pyapache_H
#define _pyapache_H

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#undef PyApache_PYTHON2

/* Apache includes */
#include "httpd.h"
#include "http_core.h"
#include "http_main.h"
#include "http_config.h"
#include "http_log.h"
#include "http_protocol.h"
#include "http_request.h"
#include "util_script.h"
#include "util_date.h"

#if MODULE_MAGIC_NUMBER >= 20010224

#define PyApache_APACHE2
#include "apr.h"
#include "apr_lib.h"
#include "apr_strings.h"
#include "apr_compat.h"

#define MODULE_VAR_EXPORT AP_MODULE_DECLARE_DATA
#define ap_get_remote_host(con,cfg,name) (ap_get_remote_host)(con,cfg,name,NULL)
#define FORBIDDEN HTTP_FORBIDDEN
#define SERVER_ERROR HTTP_INTERNAL_SERVER_ERROR
#define NOT_FOUND HTTP_NOT_FOUND
#define REDIRECT HTTP_MOVED_TEMPORARILY
#define ap_kill_timeout(r) ;
#define ap_hard_timeout(reason,r) ;
#define ap_log_reason(reason,fname,r) ap_log_rerror(APLOG_MARK, APLOG_ERR|APLOG_NOERRNO, 0, r, "%s: " reason, fname)
#define ap_can_exec(pfinfo) ((pfinfo)->protection & APR_UEXECUTE)
#define ap_send_http_header(r) ;

#else /* Apache1.3 */

#define apr_pool_t pool

#endif

/* Python includes */

#ifdef WIN32
/* XXX is this really necessary?? */
#include <Include/Python.h>
#include <Include/compile.h>
#include <Include/eval.h>
#include <Include/structmember.h>
#include <Include/marshal.h>
#include <Include/node.h>
#else
#ifndef PyApache_PYTHON2
#include <python1.5/Python.h>
#include <python1.5/compile.h>
#include <python1.5/eval.h>
#include <python1.5/structmember.h>
#include <python1.5/marshal.h>
#include <python1.5/node.h>
#else
#include <python2/Python.h>
#include <python2/compile.h>
#include <python2/eval.h>
#include <python2/structmember.h>
#include <python2/marshal.h>
#include <python2/node.h>
#endif
#endif

/* This is the structure that holds the per-directory configuration
   of this module. */
typedef struct pyapache_dir_config
{
  char *path;                   /* set with PythonPath new-path */
  int debug;                    /* set with PythonDebug On|Off */
  int verbose;                  /* set with PythonVerbose On|Off */
} pyapache_dir_config;

/* This is the structure that holds the per-server configuration
   of this module. */
typedef struct pyapache_server_config
{
  char *path;                   /* set with PyApachePath new-path */  
  char *startup;                /* set with PyApacheStartupScript filename */
  int single_interpreter;       /* set with PyApacheSingleInterpreter On|Off */
  PyObject *server_dict;        /* Server-wide NameSpace */
  PyThreadState *tstate;        /* main thread state */
} pyapache_server_config;

module MODULE_VAR_EXPORT PyApache_module;

#define PYTHON_MAGIC_TYPE       "application/x-python-httpd-cgi"
#define ALT_PYTHON_MAGIC_TYPE   "python-cgi-script"

#endif /* _pyapache_H */

/*
** Local Variables:
** change-log-default-name: "ChangeLog"
** eval: (add-hook 'write-contents-hooks '(lambda () (untabify 0 (point-max)) nil) t nil)
** End:
*/
