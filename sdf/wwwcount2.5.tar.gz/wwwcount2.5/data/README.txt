Count 2.5
=========
* Note: this file may have old olsolete info, please read the web page *

This is the README file for the binary distribution of the WWW Homepage
Access Counter for MS Windows NT.

The official Counter main page is at:
    http://www.fccc.edu/users/muquit/Count.html
Page for NT binary distribution is at:
    http://www.fccc.edu/users/muquit/CountNT.html

The official page contains the latest information.

After installation, the following directories and files will be
created in the cgi-bin (or whatever directory you chose during installation) 
directory:
<pre>
.
|-- CountNT.html
|-- README
|-- <font color="brown">Count.exe</font>               
|-- <font color="brown">extdgts.exe</font>              
|-- <font color="brown">mkstrip.exe</font>
`-- <b>wcount</b>
    |-- <b>conf</b>
    |   `-- count.cfg
    |-- <b>data</b>
    |   `-- sample.dat
    |-- <b>digits</b>
    |   |-- <b>A</b>
    |   |   |-- peng.gif
    |   |   `-- strip.gif
    |   |-- <b>B</b>
    |   |   `-- strip.gif
    |   |-- <b>C</b>
    |   |   `-- strip.gif
    |   |-- <b>D</b>
    |   |   |-- lenna.gif
    |   |   `-- strip.gif
    |   `-- <b>E</b>
    |   |   `-- strip.gif
    |   `-- <b>cd</b>
    |       `-- strip.gif
    `-- <b>logs</b>



--
Muhammad A Muquit
Nov-16-1997, Count 2.4
Jan-24-1998, updated for Count 2.5


